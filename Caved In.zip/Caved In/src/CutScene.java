import javax.swing.JPanel;

public class CutScene extends JPanel
{

}

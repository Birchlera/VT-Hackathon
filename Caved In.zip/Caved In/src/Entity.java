
public abstract class Entity
{
public abstract String getType();
}

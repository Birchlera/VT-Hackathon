import javax.swing.JPanel;

public class GameOver extends JPanel
{

}

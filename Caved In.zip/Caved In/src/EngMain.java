import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

public class EngMain
{
    public static EngMapArr maps;
    public static EngPanelHolder panels;
    public static CharWalker chara;
    public static JFrame win;

    @SuppressWarnings("static-access")
    public static void main(String[] args)
    {
        chara = new CharWalker(7, 9);
        maps = new EngMapArr();
        BufferedImage icon = null;
        panels = new EngPanelHolder();
        maps.go('*');
        panels.create(maps.getHome());
        try
        {
            icon = ImageIO.read(new File("src/icon.jpg"));
        } catch (IOException e)
        {
        }
        win = new JFrame("Cave In", null);
        win.setVisible(true);
        win.setDefaultCloseOperation(win.EXIT_ON_CLOSE);
        win.setSize(1222, 1000);
        win.setContentPane(panels.Menu());
        win.setResizable(false);
        win.setIconImage(icon);
    
        while (true)
        {

        }
    }

    public static void startGame()
    {
       
        panels.Menu().setVisible(false);
        panels.Menu().invalidate();
        win.add(panels.Map());
        Listener list = new Listener(maps.getCurrent());
        panels.Map().addKeyListener(list);
        win.setContentPane(panels.Map());
        panels.Map().requestFocus();
        panels.Map().setVisible(true);
        ((MapScreen) panels.Map()).update();

    }

    public static void pauseGame()
    {
        win.setContentPane(panels.Pause());
    }

}

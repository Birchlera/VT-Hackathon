
public class Enemy extends Entity
{
    private int x, y, lastx, lasty;
    private String type;
    public Enemy(String typeset, int xset, int yset)
    {
        type = typeset;
        x = xset;
        lastx = x;
        y = yset;
        lasty = y;
    }

    @Override
    public String getType()
    {
        return type;
    }
}


public class Floor extends Tile
{
    public Floor()
    {
        super(true, "floor");
    }

    @Override
    protected void onStep()
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    protected void onInteract()
    {
        // TODO Auto-generated method stub
        
    }
}

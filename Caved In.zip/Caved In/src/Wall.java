
public class Wall extends Tile
{
    public Wall()
    {
        super(false, "wall");
    }

    @Override
    protected void onStep()
    {
        // TODO Auto-generated method stub
        
    }

    @Override
    protected void onInteract()
    {
        // TODO Auto-generated method stub
        
    }
}

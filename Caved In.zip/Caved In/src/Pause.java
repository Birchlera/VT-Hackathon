import javax.swing.JPanel;

public class Pause extends JPanel
{

}
